Controls: 
=========

WASD - Move around
Mouse - Aim weapon
R - Use current inventory item
F - Interact/pick up
Q/E - Cycle through inventory items
Left click - Attack

Other than the controls, the game is pretty self explanatory.

- Pseudonym_Tim